STARTING THE GAME:

Apon opening the program, a title screen will appear
pressing any key on this screen will take you to the main menu

MAIN MENU:

At the main menu, you will see your credit balance in the top right of the window, as long as your credit is 1 cent or higher, you can keep playing.
You will be presented with three options:

-Would you like to spin
-collect your winnings
-view the credits

Each of these options has a number in parentheses next to it, and pressing the corresponding number on your keyboard will select this option.

SPIN:
When you select this option you will be prompted to input an amount to bet. You must input a valid number between 1 cent and your current credit or you will be
asked to input again.
Apon inputting a valid bet, the spin animation will play, and the game will generate three random numbers.
There are four possible results:

Jackpot: If you get three 7s you get a jackpot, and you will be given back your bet multiplied by 10
Triples: If you get three of any number, you will get given back your bet multiplied by 5
Doubles: If any two numbers of the result are the same, and dont qualify for thr previous options, then you will be awarded doubles, and given your bet multiplied by 3
Lose: If none of the numbers in your result match, you lose, and your bet is not returned to your credit

COLLECT WINNINGS:
Collecting your winnings will "cash out" your credit and end the game

CREDITS:
Selecting this option will cause an animation to play on the window. This can be exited once completed by  pressing any key.